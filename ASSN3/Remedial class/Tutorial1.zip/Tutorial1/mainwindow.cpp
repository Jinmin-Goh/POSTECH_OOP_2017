#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QTimer>


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);


    QTimer* timer = new QTimer();

    connect (timer, SIGNAL(timeout()),
             this, SLOT(Timeout()));

    timer->start(2000);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::Timeout()
{
    Dialog* dialog = new Dialog(this);
    hide();
    dialog->show();
}

void MainWindow::on_pushButton_clicked()
{
    Dialog* dialog = new Dialog(this);
    hide();
    dialog->show();
}


//hide();
//sec->show();
//

/*
 *
 *
 *     QTimer* timer = new QTimer();

    */
